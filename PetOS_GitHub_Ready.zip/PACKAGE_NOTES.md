Arquivos incluídos neste pacote:
- arquivos finais prontos para repositório GitHub
- sem cópias auxiliares de download (.txt alternativos)
- sem notas temporárias usadas apenas para orientação de upload

Observações:
- AGENTS.md usa a versão atualizada
- .gitignore e next.config.mts foram gerados a partir das versões auxiliares criadas para contornar limitações de download
